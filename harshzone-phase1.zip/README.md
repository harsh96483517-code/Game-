# HARSHZONE: INDIAN OPEN WORLD

Original 3D open-world game set in the fictional Indian city of Harsh Nagar.
Built with Godot 4.x and GDScript, targeting Android.

- Status: see `DEVELOPMENT_STATUS.md`
- Open tasks: see `TODO.md`
- Build and export: see `BUILD_INSTRUCTIONS.md`
