#!/usr/bin/env bash
# Project validation: required folders/files exist and every resource path in
# scenes, scripts and project.godot resolves to a real file.
# Run from anywhere: bash tests/validate_project.sh
set -u
cd "$(dirname "$0")/.."
fail=0

for d in assets/characters assets/vehicles assets/environments assets/textures assets/audio assets/animations \
         scenes/player scenes/vehicles scenes/npc scenes/world scenes/missions scenes/ui \
         scripts/player scripts/vehicles scripts/npc scripts/ai scripts/missions scripts/systems \
         materials shaders data addons tests; do
  [ -d "$d" ] || { echo "MISSING DIR:  $d"; fail=1; }
done

for f in project.godot icon.svg scenes/main.tscn scripts/systems/boot.gd \
         DEVELOPMENT_STATUS.md TODO.md BUILD_INSTRUCTIONS.md; do
  [ -f "$f" ] || { echo "MISSING FILE: $f"; fail=1; }
done

while IFS= read -r p; do
  rel="${p#res://}"
  [ -e "$rel" ] || { echo "BROKEN REFERENCE: $p"; fail=1; }
done < <(grep -rhoE 'res://[A-Za-z0-9_./-]+' --include='*.tscn' --include='*.gd' --include='project.godot' . | sort -u)

if [ "$fail" -eq 0 ]; then echo "VALIDATION PASSED"; else echo "VALIDATION FAILED"; fi
exit "$fail"
