extends Control
## Phase 1 boot screen: proves the project opens, runs and shows an FPS readout.
## Replaced by the real main menu in Phase 12.

const GAME_TITLE := "HARSHZONE: INDIAN OPEN WORLD"
const BUILD_LABEL := "Phase 1 - project setup"

var _fps_label: Label


func _ready() -> void:
	var background := ColorRect.new()
	background.color = Color(0.04, 0.04, 0.06)
	background.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	center.add_child(column)

	column.add_child(_make_label(GAME_TITLE, 44, Color(1.0, 0.6, 0.2)))
	column.add_child(_make_label(BUILD_LABEL, 22, Color(0.8, 0.8, 0.85)))
	_fps_label = _make_label("FPS: --", 20, Color(0.5, 0.9, 0.6))
	column.add_child(_fps_label)


func _process(_delta: float) -> void:
	_fps_label.text = "FPS: %d" % Engine.get_frames_per_second()


func _make_label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	return label
