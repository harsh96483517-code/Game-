# TODO

## Phase 1 follow-ups
- [ ] Open the project in Godot 4.3 and confirm the boot scene runs
- [ ] Inspect the existing GitHub repo (branch, files, workflows) and merge this skeleton in
- [ ] Decide renderer: `mobile` (better lighting, needs Vulkan) vs `gl_compatibility` (wider low-end support)

## Phase 2 (next)
- [ ] Create `export_presets.cfg` for Android (debug)
- [ ] Set package name, min/target SDK, landscape orientation
- [ ] Confirm a debug APK exports locally or in CI
