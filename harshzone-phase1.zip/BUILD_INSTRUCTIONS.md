# Build Instructions

## Run in the editor
1. Install Godot 4.3 (standard build, not .NET).
2. Open Godot, choose Import, select `project.godot`.
3. Press F5. You should see the title screen with an FPS counter.

## Validate the project
    bash tests/validate_project.sh

## Android APK
Not configured yet. Phase 2 adds the Android export preset and Phase 15 adds
the GitHub Actions workflow that builds a debug APK and uploads it as an artifact.
Signed release builds will be documented in Phase 15.
